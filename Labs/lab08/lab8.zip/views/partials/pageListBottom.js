// avatar = "https://randomuser.me/api/portraits/men/" + session.get("imageNumber") + ".jpg"
// <img src = ${avatar} width = "100" height = "100">
let bottom = `
    
        </body>
    </html>
`;

module.exports = bottom;